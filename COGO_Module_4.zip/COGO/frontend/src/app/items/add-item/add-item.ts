import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { Router } from '@angular/router';
import { ItemsService } from '../../services/items.service';
import { AuthService } from '../../services/auth.service';

@Component({
    selector: 'app-add-item',
    standalone: true,
    imports: [FormsModule, CommonModule],
    templateUrl: './add-item.html',
    styleUrl: './add-item.scss'
})
export class AddItem {

    name = '';
    description = '';
    quantity: number | null = null;
    role: string = '';

    constructor(private itemsService: ItemsService, private router: Router, private auth: AuthService) { }

    ngOnInit() {
        this.role = this.auth.getRole();
    }

    createItem() {
        const newItem = {
            name: this.name,
            description: this.description,
            quantity: this.quantity ?? 0
        };

        this.itemsService.createItem(newItem).subscribe({
            next: () => {
                this.router.navigate(['/items']);
            },
            error: (err) => console.error(err)
        });
    }
}
