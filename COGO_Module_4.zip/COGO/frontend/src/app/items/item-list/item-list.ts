import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Router } from '@angular/router';
import { ItemsService } from '../../services/items.service';
import { SearchService } from '../../services/search.service';
import { FormsModule } from '@angular/forms';


@Component({
  selector: 'app-item-list',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './item-list.html',
  styleUrl: './item-list.scss'
})
export class ItemList implements OnInit {

  items: any[] = [];
  searchTerm: string = '';
  sortOption: string = 'nameAsc';

  constructor(
    private itemsService: ItemsService,
    private router: Router,
    private searchService: SearchService
  ) { }

  ngOnInit() {

    this.searchService.search$.subscribe(text => {
      this.searchTerm = text;
    });

    this.itemsService.getItems().subscribe({
      next: (data) => { 
        this.items = data;
        this.sortItems(); 
      },
      error: (err) => console.error('Error loading items:', err)
    });
  }


  get filteredItems() {
    if (!this.searchTerm) return this.items;

    const term = this.searchTerm.toLowerCase();

    return this.items.filter(item =>
      item.name.toLowerCase().includes(term) ||
      item.description?.toLowerCase().includes(term)
    );
  }

  viewItem(item: any) {
    this.router.navigate(['/items', item._id]);
  }

  sortItems() {
    switch (this.sortOption) {

      case 'nameAsc':
        this.items.sort((a, b) => a.name.localeCompare(b.name));
        break;

      case 'nameDesc':
        this.items.sort((a, b) => b.name.localeCompare(a.name));
        break;

      case 'qtyAsc':
        this.items.sort((a, b) => a.quantity - b.quantity);
        break;

      case 'qtyDesc':
        this.items.sort((a, b) => b.quantity - a.quantity);
        break;

      case 'lowFirst':
        this.items.sort((a, b) => (a.quantity < 5 ? -1 : 1));
        break;
    }
  }

}
