import { inject } from '@angular/core';
import { Router } from '@angular/router';
import { AuthService } from '../services/auth.service';

export const adminOrManagerGuard = () => {
    const auth = inject(AuthService);
    const router = inject(Router);

    const role = auth.getRole();
    if (role === 'admin' || role === 'manager') return true;

    return router.parseUrl('/items');
};
