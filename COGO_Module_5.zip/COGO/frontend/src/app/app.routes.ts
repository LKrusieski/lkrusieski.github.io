import { Routes } from '@angular/router';
import { Login } from './login/login';
import { ItemList } from './items/item-list/item-list';
import { ItemDetail } from './items/item-detail/item-detail';
import { AddItem } from './items/add-item/add-item';
import { authGuard } from './guards/auth.guard';
import { adminGuard } from './guards/admin.guard';
import { adminOrManagerGuard } from './guards/adminOrManager.guard';

export const routes: Routes = [
  { path: '', redirectTo: 'login', pathMatch: 'full' },
  { path: 'login', component: Login },
  { path: 'items', component: ItemList, canActivate: [authGuard] },
  { path: 'items/:id', component: ItemDetail, canActivate: [authGuard] },
  { path: 'add-item', component: AddItem, canActivate: [authGuard] },

  // Add Item (admin or manager only)
  {
    path: 'add-item',
    component: AddItem,
    canActivate: [authGuard, adminOrManagerGuard]
  }
];
