import { Routes } from '@angular/router';
import { Login } from './login/login';
import { ItemList } from './items/item-list/item-list';
import { ItemDetail } from './items/item-detail/item-detail';

export const routes: Routes = [
  { path: '', redirectTo: 'login', pathMatch: 'full' },
  { path: 'login', component: Login },
  { path: 'items', component: ItemList },
  { path: 'items/:id', component: ItemDetail }
];
