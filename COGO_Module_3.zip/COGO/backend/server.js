require('dotenv').config();
const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');

const app = express();

// Middleware
app.use(cors());
app.use(express.json());

// Test route
app.get('/', (req, res) => {
    res.send('COGO backend running');
});

// Connect to MongoDB
mongoose.connect('mongodb://localhost:27017/cogoDB')
    .then(() => {
        console.log('Connected to MongoDB (cogoDB)');
        app.listen(3000, () => {
            console.log('Server running on port 3000');
        });
    })
    .catch((err) => console.error('MongoDB connection error:', err));
